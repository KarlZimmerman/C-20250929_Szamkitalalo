﻿namespace _20250929_KiNevetAVegen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Két játékos dob kockával. Annyit megy előre amennyit dobott. 
            //A cél 50-nél van. Csak pontos dobással lehet célba érni.
            //Pl: 49-en áll, akkor csak 1-es dobással léphet a célba.
            //Csak 6-os dobással lehet elindulni.
            const int CÉL = 50;

            Random random = new Random();
            
            int játékos1 = 0;
            int játékos2 = 0;


            while (játékos1 != CÉL && játékos2 != CÉL)
            {
                for (int i = 1; i < 3; i++)
                {
                    int dobás = random.Next(1, 7);
                    Console.WriteLine($"Játékos {i} dobása: {dobás}");

                    switch (i)
                    {
                        case 1:
                            if (játékos1 + dobás <= 50)
                            {
                                játékos1 += dobás;
                            }
                            else
                            {
                                Console.WriteLine("Túl nagy dobás.");
                            }
                            Console.WriteLine($"Játékos {i} poziciója: {játékos1}");
                            break;
                        case 2:
                            if (játékos2 + dobás <= 50)
                            {
                                játékos2 += dobás;
                            }
                            else
                            {
                                Console.WriteLine("Túl nagy dobás.");
                            }
                            Console.WriteLine($"Játékos {i} poziciója: {játékos2}");
                            break;
                    }
                }
            }
            if (játékos1 == CÉL)
                Console.WriteLine("Az 1-es játékos nyert");
            else
                Console.WriteLine("A 2-es játékos nyert");
        }
    }
}
