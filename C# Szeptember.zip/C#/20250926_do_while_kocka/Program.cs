﻿namespace _20250926_do_while_kocka
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Dobáljunk 2 kockával mindaddig amíg mindkettő 6-os nem lesz.
            //Hányszor kellettt dobni?

            int kocka1, kocka2, szamlalo = 0;
            Random random = new Random();

            //Hátultesztelő ciklus (a ciklusmag egyszer biztosan lefut)
            do
            {
                kocka1 = random.Next(1, 7);
                kocka2 = random.Next(1, 7);
                Console.WriteLine($"{++szamlalo}. dobás: {kocka1}, {kocka2}");
            }
            while (kocka1 != 6 || kocka2 != 6);

        }
    }
}
