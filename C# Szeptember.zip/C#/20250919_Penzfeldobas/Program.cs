﻿namespace _20250919_Penzfeldobas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 100 dobás. Hány fej és hány írás?

            Random random = new Random();
            byte fejekSzama = 0;
            for (int i = 0; i < 100; i++)
            {
                int dobas = random.Next(2);
                
                if (dobas == 0)
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                    //Console.ForegroundColor = ConsoleColor.Yellow;
                    //Console.Write("fej ");
                    fejekSzama++;
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    //Console.ForegroundColor = ConsoleColor.Red;
                    //Console.Write("írás ");
                }
                Console.Write(" ");
            }
            Console.ResetColor();
            Console.WriteLine($"\nA fejek száma: {fejekSzama}");
            Console.WriteLine($"Az írások száma: {100 - fejekSzama}");
        }
    }
}
