﻿namespace _20250926_ellenorzott_bekeres
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int ev;
            //do
            //{
            //    Console.Write("Add meg a születései évedet: ");
            //    ev = int.Parse(Console.ReadLine());
            //} while (ev < 1900 ||ev >= 2025);

            int ev;
            bool siker;
            do
            {
                Console.Write("Add meg a születései évedet: ");
                siker = int.TryParse(Console.ReadLine(), out ev);
            } while (!siker || ev < 1900 || ev >= 2025);
        }
    }
}
