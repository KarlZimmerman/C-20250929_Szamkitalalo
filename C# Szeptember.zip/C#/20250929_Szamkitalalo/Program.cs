﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20250929_Szamkitalalo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int szám = random.Next(1, 101);
            int tippekszama = 0;


            int tipp = -1;
            while (szám != tipp)
            {
                Console.Write("Tipp: ");
                tipp = int.Parse(Console.ReadLine());
                tippekszama++;
                if (tipp < szám)
                {
                    Console.WriteLine("Nagyobb a szám mint a tipp.");
                }
                else if (tipp > szám)
                {
                    Console.WriteLine("Kisebb a szám mint a tipp.");
                }
            }
            Console.WriteLine($"Talált. Tippek száma: {tippekszama}");

        }
    }
}
