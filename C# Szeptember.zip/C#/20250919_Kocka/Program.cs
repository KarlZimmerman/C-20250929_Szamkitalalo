﻿namespace _20250919_Kocka
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Kérjük be a dobások számát (n)!
            Dobjunk egy kockával n-szer!
            Számoljuk meg, hogy hány 6-os van benne! 
            */
            Random random = new Random();
            Console.Write("Kérem a dobások számát: ");
            int n = Convert.ToInt32(Console.ReadLine());
            int hatosdobások = 0;
            for (int i = 0; i < n; i++)
            {
                int dobas = random.Next(6);
                Console.WriteLine($"{i + 1}. dobás: {dobas}");
                if (dobas == 6)
                {
                    hatosdobások++;
                }
            }
            Console.WriteLine($"Hatos dobások száma: {hatosdobások}");
        }
    }
}
