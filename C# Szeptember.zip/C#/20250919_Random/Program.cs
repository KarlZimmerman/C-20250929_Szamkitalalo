﻿namespace _20250919_Random
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random(); //osztály példányosítás

            double szam;

            for (int i = 0; i < 100; i++)
            {
                //int szam = random.Next();  //0 vagy pozitív egész szám
                //int szam = random.Next();  //Exclusive upper bound (a 10 nincs benne a tartományban)
                //int szam = random.Next(10, 20); //Inclusive lower bound
                szam = random.NextDouble(); //0 és 1 közötti valós szám. Az 1 nincs benne.
                Console.Write(szam + " ");
            }
            Console.WriteLine();
            Console.WriteLine($"A legnagyobb szám az int típusban: {int.MaxValue}");
            Console.WriteLine($"A legkisebb szám az int típusban: {int.MinValue}");

            //100 és 1000 közé eső valós szám 2 tizedes pontossággal. Pl.: 234.45
            szam = Math.Round(random.Next(100, 1000) + random.NextDouble(), 2);
            szam = Math.Round(random.NextDouble() * 900 + 100, 2);  //1000-100 = 900
            szam = random.Next(10000, 100000) / 100.0;

            Console.WriteLine($"100 és 1000 közé eső valós szám 2 tizedes pontossággal: {szam}");
        }
    }
}
