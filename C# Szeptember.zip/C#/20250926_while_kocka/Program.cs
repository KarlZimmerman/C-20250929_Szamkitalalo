﻿namespace _20250926_while_kocka
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Dobáljunk 2 konckával mindaddig amig mindketto 6-os nem lesz.
            //Hányszor kellett dobni?

            Random random = new Random();
            byte kocka1 = 0, kocka2 = 0;
            //while (kocka1 != 6 || kocka2 != 6) //!!!amíg kocka 1 nem hatos vagy kocka 2 nem hatos addig megyünk bele!!!
            uint szamlalo  = 0;
            while (!(kocka1 == 6 && kocka2 == 6))
            {
                kocka1 = (byte)random.Next(1, 7);
                kocka2 = (byte)random.Next(1, 7);
                szamlalo++; //postfix, de ha ++szamlalo ← prefix
                Console.WriteLine($"{szamlalo}. dobás: {kocka1}, {kocka2}");
            }

            int a = 1, b = 2, c;
            c = a++ + --b;
            //b = 1
            //a = 2
            //c = 3 //mert a ++ postfix és a -- prefix
            Console.WriteLine($"a={a}, b={b}, c={c}");

            //Egyértelműsítve
            b--;
            c = a + b;
            a++;
        }
    }
}
