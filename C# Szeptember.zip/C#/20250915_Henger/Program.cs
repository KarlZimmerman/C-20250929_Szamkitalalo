﻿namespace _202509015_Henger
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Kérem a henger sugarát cm-ben: ");
            double r = double.Parse(Console.ReadLine());

            Console.Write("Kérem a henger magasságát cm-ben: "); 
            double h = double.Parse(Console.ReadLine());

            double A = 2 * r * Math.PI * h + r * r * Math.PI * 2;
            //Console.WriteLine($"A henger felszíne: {A:f2}");
            //Console.Writeline($"A henger felszíne: {Math.ROund(A)}"); //egészre kerekít
            Console.WriteLine($"A henger felszíne: {Math.Round}")

            //
            double

            Console

        }
    }
}
