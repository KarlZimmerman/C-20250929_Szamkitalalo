﻿namespace _20250915_Dolgozat_ertekeles
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double MAX_PONT = 200.0; //konstans: csak a definiáláskor kap értéket, később nem változtatható
            //MAX_PONT = 200; ERROR
            Console.WriteLine("$Dolgozat pontszama: (MAX:{MAX_PONT})");
            int pontszam = int.Parse(Console.ReadLine());

            //double szazalek = Convert.ToDouble(pontszam) / MAX_PONT;
            double szazalek = pontszam / MAX_PONT * 100;
            Console.WriteLine($"A dolgozat eredménye: {szazalek * 100}%");

            /*
             * 0 - 40% 1
             * 41 - 55% 2
             * 56 - 70% 3
             * 71 - 85% 4
             * 86 - 100% 5
             */

            int jegy;
            if (szazalek <= 40)
            {
                jegy = 1;
            }
            else if (szazalek <= 55)
            {
                jegy = 2;
            }
            else if (szazalek <= 70)
            { 
                jegy = 3;
            }
            else if (szazalek <= 85)
            {
                jegy = 4;
            }
            else
            {
                jegy = 5;
            }

            //Rövidebben
            if (szazalek <= 40) jegy = 1; 
            else if (szazalek <= 55) jegy = 2; 
            else if (szazalek <= 70) jegy = 3; 
            else if (szazalek <= 85) jegy = 4; 
            else jegy = 5;

            //Szöveges értékelés
            string eredmeny = "";
            switch (jegy)
                {
                    case 1: eredmeny = "elégtelen"; break;
                    case 2: eredmeny = "elégséges"; break;
                    case 3: eredmeny = "közepes"; break;
                    case 4: eredmeny = "jó"; break;
                    case 5: eredmeny = "jeles"; break;
                    //default: eredmeny = "érvenytelen jegy"; break;
                   
                }

            Console.WriteLine($"A dolgozat érdemjegye: {eredmeny} ({jegy})");
        }
    }
}
