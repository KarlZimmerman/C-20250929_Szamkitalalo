﻿namespace _20250908_ConsoleKezelés
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console osztály
            Console.Write("Hello, World!");
            Console.WriteLine("Hello, World! Enterrel a végén");
            Console.WriteLine("Entert lehet rakni \na szöveg közepére is");

            //Bekérés
            Console.Write("Kérek egy szöveget: ");
            string szöveg = Console.ReadLine(); //Egy sort olvas be (Enter) Visszaadott érték típusa: string

            ConsoleKeyInfo beolvasottKarakter = Console.ReadKey(); //Egy karaktert olvas be.
            char karakter = beolvasottKarakter.KeyChar;
            
            //egy lépésben
            char másikKarakter = Console.ReadKey().KeyChar;


            //Változó kiírás - v1
            Console.WriteLine("A szöveg változó tartalma: {0}", szöveg);
            int a = 12;
            int b = 23;
            Console.WriteLine("{0} + {1} = {2}", a, b, a+b);

            //Változó kiírás - v2
            Console.WriteLine($"{a} + {b} = {a + b}");
        }
    }
}
