﻿namespace _20250908_Adattipusok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //EGÉSZ TÍPUSOK
            int szám; //deklaráció. 32 bites egész szám
            uint aOldal; //usigned int, camelCase: többSzavasVáltozóNeve
            // aOldal = -1; ERROR
            byte éltekor;
            ulong vagyon = 123345645675678; //definíció

            char c = 'a'; //Karakter '-ok között 
            //cw - snipet
            Console.WriteLine(c);
            Console.WriteLine(c + 1);
            c = '\'';
            c = '\n';
            c = '\t';

            //ASCII kód - karakterhez rendelt kód
            //UTF8 (2Byte)

            //VALÓS TÍPUSOK
            float távolság = 123.123456789f;
            Console.WriteLine(távolság);
            double testtömeg = 72.12;
            Console.WriteLine(testtömeg);
            decimal nagyonPontosSzám = 1.122345323423423M;

            //LOGIKAI
            bool logikai = true;
            logikai = false;

            //STRING
            string szöveg = "Lorem ipsum";
            szöveg = ""; //üres sztring
        }


        void MásikFüggvény() // void - a függvény nem ad vissza semmit
        {
            /*A main() metódusban
            deklarált változók itt
            már nem elérhetők
            */
        }
    }
}
