﻿namespace _20250915_for
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // kezdőérték adás; ciklusban maradás feltétele; növekményes utasítás
            // ciklus változó; meddig mehet a ciklus változó; ciklus változó növelése/csökkentése
            // i++; egyel növeli a változó értékét
            // i--; egyel csökkenti a változó értékét
            // i változó hatóköre: a for ciklus blokkja
            for (int i = 0; i < 10; i++) // Python: range(10)
            {
                Console.Write(i + " ");
            }

            // i = 0; itt az i nem létezik

            Console.WriteLine();
            for (int i = 10; i > 0; i--)
            {
                Console.Write($"{i} ");
            }
            Console.WriteLine();

            for (int i = 2; i < 20; i+=2)
            {
                Console.Write($"{i} ");
            }
            Console.WriteLine();

            for (int i = 100; i >= 0; i -= 3)
            {
                Console.Write($"{i} ");
            }

            //for (;;)
            //{
            //    Console.WriteLine("bármi");
            //}

        }
    }
}
